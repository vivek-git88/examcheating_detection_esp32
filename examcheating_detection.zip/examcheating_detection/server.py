from flask import Flask, request, render_template, jsonify
from datetime import datetime

app = Flask(__name__)

current_status = "SAFE"
current_score = 0
current_devices = []
current_wifi = 0
current_strong = 0
current_persistence = 0

history = []

@app.route('/update', methods=['POST'])
def update():
    global current_status, current_score, current_devices
    global current_wifi, current_strong, current_persistence, history

    data = request.get_json()

    current_status = data.get("status")
    current_score = data.get("score")
    current_wifi = data.get("wifiCount")
    current_strong = data.get("strongCount")
    current_persistence = data.get("persistence")

    devices = data.get("devices")
    if devices:
        current_devices = devices.strip('|').split("|")

    timestamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")

    history.append({
        "status": current_status,
        "score": current_score,
        "time": timestamp
    })

    if len(history) > 15:
        history.pop(0)

    return "OK"

@app.route('/')
def dashboard():
    return render_template("index.html")

@app.route('/data')
def data():
    return jsonify({
        "status": current_status,
        "score": current_score,
        "devices": current_devices,
        "history": history,
        "wifi": current_wifi,
        "strong": current_strong,
        "persistence": current_persistence
    })

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)
